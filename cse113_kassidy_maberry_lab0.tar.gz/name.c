#include <stdio.h>

int main(void)
{
    printf("K      K                      \n");
    printf("K     K                       \n");
    printf("K    K                        \n");
    printf("K   K                         \n");
    printf("K  K                          \n");
    printf("K K                           \n");
    printf("KK           aaaaa      ssssss\n");
    printf("K K         a     a     s     \n");
    printf("K  K        a     a     s     \n");
    printf("K   K       a     a     ssssss\n");
    printf("K    K      a     a          s\n");
    printf("K     K     a     a          s\n");
    printf("K      K     aaaaa a    ssssss\n");
    
    return 0;
}