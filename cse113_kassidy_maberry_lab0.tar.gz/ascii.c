#include <stdio.h>

int main(void)
{
    printf("Surprised Pikachu the Meme, for those who browse reddit on the linux terminal:\n");
    printf("----------------------------------------------------------------------------------------------\n");
    printf("   #                                                                            #\n");
    printf("  ###                                                                          ###\n");
    printf("  #####                                                                       #####\n");
    printf("  ####  #                   #########################                        ###  #\n");
    printf("   ##    #          ##################         ##################           ##    #\n");
    printf("    #     #      #########                                 #########       #     #\n");
    printf("     #     #    ###                                               ###     #     #\n");
    printf("      #     ## ###      #                              #             ### ##     #\n");
    printf("       #      #      #  ##                          #  ##               #      #\n");
    printf("        #            #####                          #####                     #\n"); 
    printf("       # ##            ##                             ##                    ## #\n");
    printf("      #                             #####                                      #\n");
    printf("     #                               ####                                       #\n");
    printf("     # $$$$                                                                 $$$$ #\n");
    printf("    #$$$$$$$                       #########                               $$$$$$$$#\n");
    printf("   #$$$$$$$$                      #$$$$$$$$$#                               $$$$$$$$#\n");
    printf("  #$$$$$$$$                       #$$$$$$$$$#                                $$$$$$$#\n");
    printf("  #$$$$$$$                        #$$$$$$$$$#                                 $$$$$$$#\n");
    printf(" # $$$$$$                          #########                                    $$$$$ #\n");
    printf("#                                                                                      #\n");
    printf("#                                                                                      #\n");
    printf("#                                                                                       #\n");
    printf(" #                                                                                       #\n");
    printf("  #                                                                                       #\n");
    printf("   #                                                                                       #\n");
    printf("    ##                                                                                       #\n");
    printf("----------------------------------------------------------------------------------------------\n");
    printf("If it the lines don't look mostly smooth it or have gaps the terminal needs to be a bigger window.\n");   
}